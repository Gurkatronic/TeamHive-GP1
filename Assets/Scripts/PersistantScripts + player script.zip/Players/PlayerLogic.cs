using UnityEngine;

public class PlayerLogic : MonoBehaviour, IDamageable
{
    public int health = 100;
    public int damage = 10;
    public int killStreak = 0;
    public int streakNeededForRage = 10;
    public bool knockedDown = false;
    public bool rageMode = false;
    public float attackCooldown = 0.2f;
    public float lastAttackTime = 0f;
    public float attackDuration = 0.05f;
    public float rageAttackCooldown = 0.05f;
    public float rageAttackDuration = 0.02f;
    public float time = 0f;


    private void Update()
    {
        time += Time.deltaTime;
    }

    public int OnDamage(int damage)
    {
        Debug.Log("player took damage: " + damage);
        health -= damage;
        if (health <= 0)
        {
            knockedDown = true;
            return 1;
        }
        return 0;
    }
}
