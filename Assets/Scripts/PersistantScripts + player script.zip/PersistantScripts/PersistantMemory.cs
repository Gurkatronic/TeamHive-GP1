using UnityEngine;
using System.Collections.Generic;

public class SessionPackage {
    List<PlayableCharacterScriptableObject> activePlayers = new();
}


public class PersistantMemory : MonoBehaviour
{
    
    SessionPackage lastSessionPackage;


    private void Awake() {
        DontDestroyOnLoad(this);
    }

    public SessionPackage StartSession() {
        return lastSessionPackage;
    }
}
