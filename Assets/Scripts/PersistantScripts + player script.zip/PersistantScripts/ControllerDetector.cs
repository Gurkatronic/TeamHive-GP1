using UnityEngine;
using UnityEngine.InputSystem;
using System.Collections.Generic;
using UnityEngine.InputSystem.Utilities;
using System;
using UnityEngine.InputSystem.Users;

public class ControllerDetector : MonoBehaviour
{
    private enum SceneState {
        CharacterSelect,
        Gameplay
    }
    [Serializable]
    public class PlayerSlot {
        public int slotIndex;
        public InputUser user;
        public Gamepad gamepad;
        public bool isConnected;
    }

    public PlayerSlot[] slots = new PlayerSlot[4];
    [SerializeField] SceneState currentState = SceneState.CharacterSelect;
    //this one will follow around the scenes so it will not be destroyed,
    //handle what happens when you add a controller or drop a controller in scenes
    [SerializeField] List<Gamepad> activeGamepads;
    IDisposable anyButtonListener;

    private void Awake() {
        DontDestroyOnLoad(this);

        for(int i = 0; i < slots.Length; i++) {
            slots[i] = new PlayerSlot { slotIndex = i };
        }

        
    }


    private void OnEnable() {
        anyButtonListener = InputSystem.onAnyButtonPress.Call(OnAnyButtonPress);
        InputSystem.onDeviceChange += OnDeviceChange;
    }

    private void OnDisable() {
        anyButtonListener?.Dispose();
        InputSystem.onDeviceChange -= OnDeviceChange;
    }
    private void Update() {
        if(Keyboard.current != null && Keyboard.current.spaceKey.wasPressedThisFrame) {
            
        }
    }


    void OnDeviceChange(InputDevice device, InputDeviceChange change) {
        if (device is not Gamepad gamepad) return;

        if (change == InputDeviceChange.Disconnected) {
            for (int i = 0; i < slots.Length; i++) {
                if (slots[i].isConnected && slots[i].gamepad == gamepad) {
                    slots[i].isConnected = false;
                    Debug.Log($"Player {i} controller disconnected!");
                }
            }
        }
    }
    private void OnAnyButtonPress(InputControl control) {
        Debug.Log("Some button pressed");
        //Check what type of device it is. Should map this so keyboard can be used for one controller scheme
        // Ignore keyboards, mice, or non-gamepad devices
        if (control.device is not Gamepad gamepad) {
            Debug.Log("This is not a gamepad");
            return;
        }
        

        for(int i = 0; i < slots.Length; i++) {
            if (slots[i].isConnected && slots[i].gamepad == gamepad)
                return;
        }

        for(int i = 0; i < slots.Length; i++) {
            PlayerSlot playerSlot = slots[i];
            if (!playerSlot.isConnected) {
                playerSlot.user = InputUser.PerformPairingWithDevice(gamepad);
                playerSlot.gamepad = gamepad;
                playerSlot.isConnected = true;
                Debug.Log($"Player {i} joined with gamepad {gamepad.displayName}");
                return;
            }
        }
    }

    public void OnPlayerJoined(PlayerInput playerInput) { 
        switch(currentState) {
            case SceneState.CharacterSelect:
                //ADD from characterselect 
                //this should call the mainmenu script
                Debug.Log("This is characterselect join");
                break;
            case SceneState.Gameplay:
                Debug.Log("This is GameplayJoin");
                break;
        }
    }

    public void PlayerDisconnect(PlayerInput playerInput) {
        switch (currentState) {
            case SceneState.CharacterSelect:
                Debug.Log("Lost input in character select");
                //Remove from character select window
                //this should talk to the main menu script
                break;
            case SceneState.Gameplay:
                Debug.Log("Lost input in game");
                break;
        }
    }

}
